#!/usr/bin/env sh

gsl project.xml

chmod +x autogen.sh version.sh
