[![Build Status](https://travis-ci.org/mkoppanen/php-nano.png?branch=master)](https://travis-ci.org/mkoppanen/php-nano)

nanomsg extension for PHP
=========================

For more information about nanomsg see: http://nanomsg.org/